import mysql.connector


con = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="sistema_a"
)


cursor = con.cursor()

## cadrastrar usuarios vendedores

cursor.execute("""
INSERT INTO usuarios (nome, email, id_departamento) 
VALUES 
('Gustavo Queiroz', 'gustavo@sistema.com', 1),
('Mariana Silva', 'mariana@sistema.com', 1),
('Carlos Souza', 'carlos@sistema.com', 1);
""")
con.commit()
con.close()
