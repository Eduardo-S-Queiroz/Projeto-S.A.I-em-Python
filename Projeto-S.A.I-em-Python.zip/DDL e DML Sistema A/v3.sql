use sistema_a

select * from clientes limit 20

select * from produtos

select * from usuarios

/* drop table clientes

-- Caso necessário recrie a tabela clientes o id precisa estar no intervalo 1 a 187

CREATE TABLE sistema_a.clientes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(150),
    data_nasc DATE,
    contexto_historico TEXT,
    cidade VARCHAR(100),
    uf VARCHAR(2),
    email VARCHAR(150),
    telefone VARCHAR(20),
    estado_civil VARCHAR(50),
    endereco TEXT,
    cpf VARCHAR(20)
);

*/
-- DDL


/* =====================================================
   CRIAÇÃO DAS TABELAS
===================================================== */

CREATE TABLE categoria (

    id_categoria INT AUTO_INCREMENT PRIMARY KEY,

    nome_categoria VARCHAR(200) NOT NULL

);


CREATE TABLE fornecedor (

    id_fornecedor INT AUTO_INCREMENT PRIMARY KEY,

    nome_fornecedor VARCHAR(200) NOT NULL

);


/* =====================================================
   TABELA PRODUTOS
===================================================== */

CREATE TABLE produtos (

    id_produto INT AUTO_INCREMENT PRIMARY KEY,

    id_categoria INT NOT NULL,

    id_fornecedor INT NOT NULL,

    nome_produto VARCHAR(200) NOT NULL,

    preco DECIMAL(10,2) NOT NULL,

    imagem_produto TEXT,

    /* FOREIGN KEYS */

    CONSTRAINT fk_produto_categoria
    FOREIGN KEY (id_categoria)
    REFERENCES categoria(id_categoria),

    CONSTRAINT fk_produto_fornecedor
    FOREIGN KEY (id_fornecedor)
    REFERENCES fornecedor(id_fornecedor)

);


CREATE TABLE vendas (

    id_venda INT AUTO_INCREMENT PRIMARY KEY,

    id_cliente INT NOT NULL,

    id_produto INT NOT NULL,

    id_usuario INT NOT NULL,

    data_venda DATE NOT NULL,

    quantidade INT NOT NULL,

    valor_unitario DECIMAL(10,2) NOT NULL,

    aliquota_icms DECIMAL(5,2) NOT NULL,

    aliquota_pis DECIMAL(5,2) NOT NULL,

    aliquota_cofins DECIMAL(5,2) NOT NULL,

    FOREIGN KEY (id_cliente)
    REFERENCES clientes(id),

    FOREIGN KEY (id_produto)
    REFERENCES produtos(id_produto),

    FOREIGN KEY (id_usuario)
    REFERENCES usuarios(id)

);


-- DML

/* =====================================================
   CATEGORIAS
===================================================== */

INSERT INTO categoria (nome_categoria)
VALUES
('Notebook'),
('Monitor'),
('Servidor'),
('Rack'),
('Memória RAM'),
('HD'),
('SSD'),
('Mouse'),
('Teclado'),
('Fonte'),
('Placa de Vídeo'),
('Servidor de HD'),
('Switch'),
('Roteador'),
('Access Point');



/* =====================================================
   FORNECEDORES
===================================================== */

INSERT INTO fornecedor (nome_fornecedor)
VALUES
('Dell'),
('Kingston'),
('Samsung'),
('Lenovo'),
('LG'),
('HP'),
('Asus'),
('Acer'),
('Cisco'),
('TP-Link'),
('Intelbras'),
('Seagate'),
('Western Digital'),
('HyperX'),
('Corsair'),
('Nvidia'),
('AMD'),
('Logitech');


/* =====================================================
   PRODUTOS
===================================================== */

INSERT INTO produtos
(
    id_categoria,
    id_fornecedor,
    nome_produto,
    preco,
    imagem_produto
)

VALUES

/* NOTEBOOKS */

(1, 1,
'Dell Inspiron 15',
4599.90,
'https://images.unsplash.com/photo-1496181133206-80ce9b88a853'),

(1, 4,
'Lenovo ThinkPad E14',
5399.90,
'https://images.unsplash.com/photo-1517336714739-489689fd1ca8'),

(1, 7,
'Asus Vivobook 15',
3999.90,
'https://images.unsplash.com/photo-1525547719571-a2d4ac8945e2'),

/* MONITORES */

(2, 5,
'Monitor LG UltraWide 29',
1299.90,
'https://images.unsplash.com/photo-1527443154391-507e9dc6c5cc'),

(2, 3,
'Monitor Samsung Odyssey',
2499.90,
'https://images.unsplash.com/photo-1545239351-1141bd82e8a6'),

/* SERVIDORES */

(3, 1,
'Dell PowerEdge T40',
12999.90,
'https://images.unsplash.com/photo-1558494949-ef010cbdcc31'),

(3, 6,
'Servidor HP ProLiant',
15499.90,
'https://images.unsplash.com/photo-1518770660439-4636190af475'),

/* RACK */

(4, 11,
'Rack Servidor 44U',
3899.90,
'https://images.unsplash.com/photo-1516321318423-f06f85e504b3'),

/* MEMÓRIA */

(5, 2,
'Memória Kingston 16GB DDR4',
429.90,
'https://images.unsplash.com/photo-1562976540-1502c2145186'),

(5, 14,
'Memória HyperX Fury 32GB',
899.90,
'https://images.unsplash.com/photo-1587202372775-e229f172b9d7'),

/* HD */

(6, 12,
'HD Seagate 2TB',
459.90,
'https://images.unsplash.com/photo-1531498860502-7c67cf02f657'),

(6, 13,
'HD WD Blue 1TB',
329.90,
'https://images.unsplash.com/photo-1587202372634-32705e3bf49c'),

/* SSD */

(7, 3,
'SSD Samsung EVO 1TB',
699.90,
'https://images.unsplash.com/photo-1591799265444-d66432b91588'),

/* MOUSE */

(8, 18,
'Mouse Logitech MX Master',
499.90,
'https://images.unsplash.com/photo-1527814050087-3793815479db'),

/* TECLADO */

(9, 18,
'Teclado Logitech Mechanical',
699.90,
'https://images.unsplash.com/photo-1511467687858-23d96c32e4ae'),

/* FONTE */

(10, 15,
'Fonte Corsair 750W',
649.90,
'https://images.unsplash.com/photo-1587202372616-b43abea06c2a'),

/* PLACA DE VIDEO */

(11, 16,
'NVIDIA RTX 4070',
4999.90,
'https://images.unsplash.com/photo-1591488320449-011701bb6704'),

/* SWITCH */

(13, 9,
'Switch Cisco 24 Portas',
3499.90,
'https://images.unsplash.com/photo-1518770660439-4636190af475'),

/* ROTEADOR */

(14, 10,
'Roteador TP-Link AX5400',
899.90,
'https://images.unsplash.com/photo-1558494949-ef010cbdcc31'),

/* ACCESS POINT */

(15, 11,
'Access Point Intelbras',
799.90,
'https://images.unsplash.com/photo-1516321318423-f06f85e504b3');


