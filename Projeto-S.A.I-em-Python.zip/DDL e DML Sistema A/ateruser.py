import mysql.connector

mydb = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="sistema_a"
)

mycursor = mydb.cursor()

mycursor.execute("""
                 ALTER TABLE usuarios 
ADD COLUMN celular INT(11) NOT NULL;
""")

mydb.commit()
mydb.close()