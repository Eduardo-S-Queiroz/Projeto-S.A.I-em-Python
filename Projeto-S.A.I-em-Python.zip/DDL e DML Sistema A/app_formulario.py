from flask import Flask, render_template, request, redirect, session, send_file
from io import BytesIO
import pandas as pd
import mysql.connector
import math
import json



app = Flask(__name__)
app.secret_key = "123"

def conectar():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="sistema_a"
    )


@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        usuario = request.form["usuario"]
        senha = request.form["senha"]

        con = conectar()
        cursor = con.cursor()

        cursor.execute(
            "SELECT * FROM usuarios WHERE nome=%s AND senha=%s",
            (usuario, senha)
        )

        user = cursor.fetchone()
        cursor.close()
        con.close()

        if user:
            session["usuario"] = usuario
            return redirect("/main")
        else:
            return "Login inválido"

    return render_template("login.html")

@app.route("/main") 

def main(): 
    return render_template("main.html")

@app.route("/home")
def home():
    return render_template("home.html")


@app.route("/servicos")
def servicos():
    return render_template("servicos.html")


@app.route("/ecommerce")

def ecommerce():

    con = conectar()

    cursor = con.cursor()

    # filtros recebidos da URL

    nome_produto = request.args.get(
        "nome_produto",""
    )

    fornecedor = request.args.get(
        "fornecedor",""
    )

    categoria = request.args.get(
        "categoria",""
    )

    query = """

    SELECT

        p.id_produto,
        p.nome_produto,
        p.preco,
        p.imagem_produto,
        f.nome_fornecedor,
        c.nome_categoria

    FROM produtos p

    INNER JOIN fornecedor f
    ON p.id_fornecedor=f.id_fornecedor

    INNER JOIN categoria c
    ON p.id_categoria=c.id_categoria

    WHERE 1=1

    """

    parametros=[]

    # filtro nome

    if nome_produto:

        query += """

        AND p.nome_produto
        LIKE %s

        """

        parametros.append(
            "%" + nome_produto + "%"
        )

    # filtro fornecedor

    if fornecedor:

        query += """

        AND p.id_fornecedor=%s

        """

        parametros.append(
            fornecedor
        )

    # filtro categoria

    if categoria:

        query += """

        AND p.id_categoria=%s

        """

        parametros.append(
            categoria
        )

    cursor.execute(
        query,
        parametros
    )

    produtos = cursor.fetchall()

    # lista fornecedores

    cursor.execute("""

    SELECT
    id_fornecedor,
    nome_fornecedor

    FROM fornecedor

    """)

    fornecedores = cursor.fetchall()

    # lista categorias

    cursor.execute("""

    SELECT
    id_categoria,
    nome_categoria

    FROM categoria

    """)

    categorias = cursor.fetchall()

    cursor.close()
    con.close()

    return render_template(

        "ecommerce.html",

        produtos=produtos,
        fornecedores=fornecedores,
        categorias=categorias

    )



@app.route("/sobre")
def sobre():
    return render_template("sobre.html")


@app.route("/contato")
def contato():
    return render_template("contato.html")


@app.route("/clientes")
def clientes():
    con = conectar()
    cursor = con.cursor()

    cursor.execute("SELECT id, nome, cidade, telefone, cpf FROM clientes")
    dados = cursor.fetchall()

    cursor.close()
    con.close()

    return render_template("clientes.html", clientes=dados)


@app.route("/novo_cliente", methods=["GET", "POST"])
def novo_cliente():
    if request.method == "POST":

        dados = (
            request.form["nome"],
            request.form["data_nasc"],
            request.form["contexto_historico"],
            request.form["cidade"],
            request.form["uf"],
            request.form["email"],
            request.form["telefone"],
            request.form["estado_civil"],
            request.form["endereco"],
            request.form["cpf"]
        )

        con = conectar()
        cursor = con.cursor()

        cursor.execute("""
            INSERT INTO clientes (
                nome, data_nasc, contexto_historico, cidade, uf,
                email, telefone, estado_civil, endereco, cpf
            ) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
        """, dados)

        con.commit()
        cursor.close()
        con.close()

        return redirect("/clientes")

    return render_template("novo_cliente.html", cliente=None)

@app.route("/editar/<int:id>", methods=["GET", "POST"])
def editar(id):
    con = conectar()
    cursor = con.cursor(dictionary=True)  # 👈 IMPORTANTE

    if request.method == "POST":
        dados = (
            request.form["nome"],
            request.form["data_nasc"],
            request.form["contexto_historico"],
            request.form["cidade"],
            request.form["uf"],
            request.form["email"],
            request.form["telefone"],
            request.form["estado_civil"],
            request.form["endereco"],
            request.form["cpf"],
            id
        )

        cursor.execute("""
            UPDATE clientes SET
                nome=%s,
                data_nasc=%s,
                contexto_historico=%s,
                cidade=%s,
                uf=%s,
                email=%s,
                telefone=%s,
                estado_civil=%s,
                endereco=%s,
                cpf=%s
            WHERE id=%s
        """, dados)

        con.commit()
        cursor.close()
        con.close()

        return redirect("/clientes")

    cursor.execute("""
        SELECT id, nome, data_nasc, contexto_historico, cidade, uf,
               email, telefone, estado_civil, endereco, cpf
        FROM clientes WHERE id=%s
    """, (id,))

    cliente = cursor.fetchone()

    cursor.close()
    con.close()

    return render_template("novo_cliente.html", cliente=cliente)


@app.route("/excluir/<int:id>", methods=["GET", "POST"])
def excluir(id):

    con = conectar()
    cursor = con.cursor(dictionary=True)

    if request.method == "POST":
        cursor.execute("DELETE FROM clientes WHERE id=%s", (id,))
        con.commit()

        cursor.close()
        con.close()

        return redirect("/clientes")

    # BUSCA O CLIENTE PARA MOSTRAR NA TELA
    cursor.execute("""
        SELECT nome, cpf, cidade, telefone 
        FROM clientes WHERE id=%s
    """, (id,))

    cliente = cursor.fetchone()

    cursor.close()
    con.close()

    return render_template("excluir_cliente.html", cliente=cliente, id=id)


@app.route("/relatorios") 

def relatorios(): 

	con = conectar() 
	cursor = con.cursor() 
	
	cursor.execute(""" 
		SELECT 	id, 
				nome, 
				cpf 
		FROM clientes 
	""") 
	
	clientes = cursor.fetchall() 
	
	cursor.close() 
	
	con.close() 
	
	return render_template(

		"relatorios.html", clientes=clientes 
	)


@app.route("/novo_usuario", methods=["GET", "POST"])
def novo_usuario():

    con = conectar()
    cursor = con.cursor()

    cursor.execute("""
        SELECT id_departamento, nome_departamento
        FROM departamento
    """)

    departamento = cursor.fetchall()

    if request.method == "POST":

        nome = request.form["nome"]
        email = request.form["email"]
        senha = request.form["senha"]
        celular = request.form["celular"]
        id_departamento = request.form["id_departamento"]

        cursor.execute("""
            INSERT INTO usuarios
            (
                nome,
                email,
                senha,
                celular,
                id_departamento
            )
            VALUES (%s,%s,%s,%s,%s)
        """, (
            nome,
            email,
            senha,
            celular,
            id_departamento
        ))

        con.commit()

        cursor.close()
        con.close()

        return redirect("/usuarios")

    cursor.close()
    con.close()

    return render_template(
        "novo_usuario.html",
        departamento=departamento
    )


@app.route("/editar_usuario/<int:id>", methods=["GET", "POST"])
def editar_usuario(id):

    con = conectar()
    cursor = con.cursor()

    cursor.execute("""
        SELECT id_departamento, nome_departamento
        FROM departamento
    """)

    departamento = cursor.fetchall()

    if request.method == "POST":

        nome = request.form["nome"]
        email = request.form["email"]
        senha = request.form["senha"]
        celular = request.form["celular"]
        id_departamento = request.form["id_departamento"]

        cursor.execute("""
            UPDATE usuarios
            SET
                nome=%s,
                email=%s,
                senha=%s,
                celular=%s,
                id_departamento=%s
            WHERE id_departamento=%s
        """, (
            nome,
            email,
            senha,
            celular,
            id_departamento,
            id
        ))

        con.commit()

        cursor.close()
        con.close()

        return redirect("/usuarios")

    cursor.execute("""
        SELECT
            nome,
            email,
            senha,
            celular,
            id_departamento
        FROM usuarios
        WHERE id=%s
    """, (id,))

    usuario = cursor.fetchone()

    cursor.close()
    con.close()

    return render_template(
        "novo_usuario.html",
        usuario=usuario,
        departamento=departamento
    )


@app.route("/usuarios")
def usuarios():

    con = conectar()
    cursor = con.cursor()

    cursor.execute("""
        SELECT
            u.id,
            u.nome,
            u.email,
            u.celular,
            d.nome_departamento
        FROM usuarios u
        LEFT JOIN departamento d
        ON u.id_departamento = d.id_departamento
    """)

    dados = cursor.fetchall()

    cursor.close()
    con.close()

    return render_template(
        "usuarios.html",
        usuarios=dados
    )


@app.route("/excluir_usuario/<int:id>", methods=["GET", "POST"])

def excluir_usuario(id):

    con = conectar()
    cursor = con.cursor()

    cursor.execute("""
        SELECT id, nome, email
        FROM usuarios
        WHERE id=%s
    """, (id,))

    usuario = cursor.fetchone()

    if request.method == "POST":

        cursor.execute("""
            DELETE FROM usuarios
            WHERE id=%s
        """, (id,))

        con.commit()

        cursor.close()
        con.close()

        return redirect("/usuarios")

    cursor.close()
    con.close()

    return render_template(
        "excluir_usuario.html",
        usuario=usuario
    )
    



@app.route("/categorias", methods=["GET","POST"]) 

def categorias(): 
    con = conectar() 
    cursor = con.cursor() 
    
    cursor.execute(""" 
                SELECT 
                   id_categoria, 
                   nome_categoria 
                FROM categoria """) 
    
    dados = cursor.fetchall() 
    cursor.close() 
    con.close() 

    return render_template(
         "categorias.html", 
         categorias=dados )

@app.route("/nova_categoria", methods=["GET","POST"]) 

def nova_categoria(): 
    
    if request.method == "POST": 
        
        nome_categoria = request.form["nome_categoria"] 
        
        con = conectar() 
        
        cursor = con.cursor() 
        
        cursor.execute(""" 
                       
                       INSERT INTO categoria (nome_categoria) 
                       
                       VALUES (%s) 
                       
                       """, (nome_categoria,)) 
        
        con.commit() 
        cursor.close() 
        con.close() 
        
        return redirect("/categorias") 
    
    
    return render_template( 
        "nova_categoria.html" 
        )
 


@app.route("/editar_categoria/<int:id>", methods=["GET","POST"])

def editar_categoria(id):

    con = conectar()

    cursor = con.cursor()

    if request.method == "POST":

        nome_categoria = request.form["nome_categoria"]

        cursor.execute("""

        UPDATE categoria

        SET nome_categoria=%s

        WHERE id_categoria=%s

        """,
        (
            nome_categoria,
            id
        ))

        con.commit()

        cursor.close()
        con.close()

        return redirect("/categorias")

    cursor.execute("""

    SELECT nome_categoria

    FROM categoria

    WHERE id_categoria=%s

    """,
    (id,))

    categoria = cursor.fetchone()

    cursor.close()
    con.close()

    return render_template(
        "nova_categoria.html",
        categoria=categoria
    )



@app.route("/excluir_categoria/<int:id>",methods=["GET","POST"])

def excluir_categoria(id):

    con = conectar()

    cursor = con.cursor()

    if request.method == "POST":

        cursor.execute("""

        DELETE FROM categoria

        WHERE id_categoria=%s

        """,
        (id,))

        con.commit()

        cursor.close()
        con.close()

        return redirect("/categorias")

    cursor.execute("""

    SELECT
    id_categoria,
    nome_categoria

    FROM categoria

    WHERE id_categoria=%s

    """,
    (id,))

    categoria = cursor.fetchone()

    cursor.close()
    con.close()

    return render_template(
        "excluir_categoria.html",
        categoria=categoria
    )



@app.route("/fornecedores",methods=["GET","POST"])
def fornecedores():

    con = conectar()

    cursor = con.cursor()

    cursor.execute("""

    SELECT
    id_fornecedor,
    nome_fornecedor

    FROM fornecedor

    """)

    dados = cursor.fetchall()

    cursor.close()
    con.close()

    return render_template(
        "fornecedores.html",
        fornecedores=dados
    )


@app.route("/novo_fornecedor",methods=["GET","POST"])

def novo_fornecedor():

    if request.method == "POST":

        nome_fornecedor = request.form["nome_fornecedor"]

        con = conectar()

        cursor = con.cursor()

        cursor.execute("""

        INSERT INTO fornecedor
        (nome_fornecedor)

        VALUES (%s)

        """,
        (nome_fornecedor,))

        con.commit()

        cursor.close()
        con.close()

        return redirect("/fornecedores")

    return render_template(
        "novo_fornecedor.html"
    )


@app.route("/editar_fornecedor/<int:id>",methods=["GET","POST"])

def editar_fornecedor(id):

    con = conectar()

    cursor = con.cursor()

    if request.method == "POST":

        nome_fornecedor = request.form["nome_fornecedor"]

        cursor.execute("""

        UPDATE fornecedor

        SET nome_fornecedor=%s

        WHERE id_fornecedor=%s

        """,
        (
            nome_fornecedor,
            id
        ))

        con.commit()

        cursor.close()
        con.close()

        return redirect("/fornecedores")

    cursor.execute("""

    SELECT nome_fornecedor

    FROM fornecedor

    WHERE id_fornecedor=%s

    """,
    (id,))

    fornecedor = cursor.fetchone()

    cursor.close()
    con.close()

    return render_template(
        "novo_fornecedor.html",
        fornecedor=fornecedor
    )



@app.route("/excluir_fornecedor/<int:id>",methods=["GET","POST"])

def excluir_fornecedor(id):

    con = conectar()

    cursor = con.cursor()

    if request.method == "POST":

        cursor.execute("""

        DELETE FROM fornecedor

        WHERE id_fornecedor=%s

        """,
        (id,))

        con.commit()

        cursor.close()
        con.close()

        return redirect("/fornecedores")

    cursor.execute("""

    SELECT
    id_fornecedor,
    nome_fornecedor

    FROM fornecedor

    WHERE id_fornecedor=%s

    """,
    (id,))

    fornecedor = cursor.fetchone()

    cursor.close()
    con.close()

    return render_template(
        "excluir_fornecedor.html",
        fornecedor=fornecedor
    )



@app.route("/produtos")
def produtos():

    con = conectar()

    cursor = con.cursor()

    query = """

    SELECT

        p.id_produto,
        p.nome_produto,
        c.nome_categoria,
        f.nome_fornecedor,
        p.preco,
        p.imagem_produto

    FROM produtos p

    INNER JOIN categoria c
    ON p.id_categoria = c.id_categoria

    INNER JOIN fornecedor f
    ON p.id_fornecedor = f.id_fornecedor

    """

    cursor.execute(query)

    produtos = cursor.fetchall()

    cursor.close()
    con.close()

    return render_template(
        "produtos.html",
        produtos=produtos
    )


@app.route("/novo_produto",
methods=["GET","POST"])

def novo_produto():

    con = conectar()

    cursor = con.cursor()

    if request.method == "POST":

        nome_produto = request.form["nome_produto"]

        preco = request.form["preco"]

        imagem_produto = request.form["imagem_produto"]

        id_categoria = request.form["id_categoria"]

        id_fornecedor = request.form["id_fornecedor"]

        cursor.execute("""

        INSERT INTO produtos
        (
            nome_produto,
            preco,
            imagem_produto,
            id_categoria,
            id_fornecedor
        )

        VALUES
        (%s,%s,%s,%s,%s)

        """,
        (
            nome_produto,
            preco,
            imagem_produto,
            id_categoria,
            id_fornecedor
        ))

        con.commit()

        cursor.close()
        con.close()

        return redirect("/produtos")

    # CATEGORIAS

    cursor.execute("""

    SELECT
    id_categoria,
    nome_categoria

    FROM categoria

    """)

    categorias = cursor.fetchall()

    # FORNECEDORES

    cursor.execute("""

    SELECT
    id_fornecedor,
    nome_fornecedor

    FROM fornecedor

    """)

    fornecedores = cursor.fetchall()

    cursor.close()
    con.close()

    return render_template(
        "novo_produto.html",
        categorias=categorias,
        fornecedores=fornecedores
    )


@app.route("/editar_produto/<int:id>",
methods=["GET","POST"])

def editar_produto(id):

    con = conectar()

    cursor = con.cursor()

    if request.method == "POST":

        nome_produto = request.form["nome_produto"]

        preco = request.form["preco"]

        imagem_produto = request.form["imagem_produto"]

        id_categoria = request.form["id_categoria"]

        id_fornecedor = request.form["id_fornecedor"]

        cursor.execute("""

        UPDATE produtos

        SET

            nome_produto=%s,
            preco=%s,
            imagem_produto=%s,
            id_categoria=%s,
            id_fornecedor=%s

        WHERE id_produto=%s

        """,
        (
            nome_produto,
            preco,
            imagem_produto,
            id_categoria,
            id_fornecedor,
            id
        ))

        con.commit()

        cursor.close()
        con.close()

        return redirect("/produtos")

    # PRODUTO

    cursor.execute("""

    SELECT

        id_categoria,
        id_fornecedor,
        nome_produto,
        preco,
        imagem_produto

    FROM produtos

    WHERE id_produto=%s

    """,
    (id,))

    produto = cursor.fetchone()

    # CATEGORIAS

    cursor.execute("""

    SELECT
    id_categoria,
    nome_categoria

    FROM categoria

    """)

    categorias = cursor.fetchall()

    # FORNECEDORES

    cursor.execute("""

    SELECT
    id_fornecedor,
    nome_fornecedor

    FROM fornecedor

    """)

    fornecedores = cursor.fetchall()

    cursor.close()
    con.close()

    return render_template(
        "novo_produto.html",
        produto=produto,
        categorias=categorias,
        fornecedores=fornecedores
    )



@app.route("/excluir_produto/<int:id>",
methods=["GET","POST"])

def excluir_produto(id):

    con = conectar()

    cursor = con.cursor()

    if request.method == "POST":

        cursor.execute("""

        DELETE FROM produtos

        WHERE id_produto=%s

        """,
        (id,))

        con.commit()

        cursor.close()
        con.close()

        return redirect("/produtos")

    cursor.execute("""

    SELECT

        p.id_produto,
        p.nome_produto,
        c.nome_categoria,
        f.nome_fornecedor,
        p.preco

    FROM produtos p

    INNER JOIN categoria c
    ON p.id_categoria = c.id_categoria

    INNER JOIN fornecedor f
    ON p.id_fornecedor = f.id_fornecedor

    WHERE p.id_produto=%s

    """,
    (id,))

    produto = cursor.fetchone()

    cursor.close()
    con.close()

    return render_template(
        "excluir_produto.html",
        produto=produto
    )

# ======================================================
# RELATÓRIOS
#
# RELATÓRIO VENDAS OPERACIONAL
# ======================================================


@app.route(
"/relatorio_vendas_operacional", methods=["GET"]
)
def relatorio_vendas_operacional():

    con=conectar()

    cursor=con.cursor()

    data_inicio=request.args.get("data_inicio")

    data_fim=request.args.get("data_fim")

    produto=request.args.get("produto","")
  
    fornecedor=request.args.get("fornecedor")

    categoria=request.args.get("categoria")

    vendedor=request.args.get("vendedor")

    pagina=int(request.args.get( "pagina",1))

    registros_por_pagina=50

    offset=(pagina-1)*registros_por_pagina

    # Combos

    cursor.execute("""
    SELECT  id_fornecedor,
            nome_fornecedor
    FROM fornecedor
    ORDER BY nome_fornecedor
    """)

    fornecedores=cursor.fetchall()

    cursor.execute("""
    SELECT  id_categoria,
            nome_categoria
    FROM categoria
    ORDER BY nome_categoria
    """)

    categorias=cursor.fetchall()

    dados=[]

    total_paginas=1

    cursor.execute("""
        SELECT	u.id as id_usuario,
		        u.nome
        FROM usuarios u
	        INNER JOIN departamento d
		        ON d.id_departamento=u.id_departamento
        WHERE d.nome_departamento='Vendas'
        ORDER BY u.nome
     """)

    vendedores=cursor.fetchall()

    if data_inicio and data_fim:

        query="""
            SELECT  DATE_FORMAT(v.data_venda, '%d/%m/%Y') AS Data,
                    p.nome_produto,
                    f.nome_fornecedor,
                    c.nome_categoria,
                    u.nome AS vendedor,
                    d.nome_departamento AS departamento,
                    v.quantidade,
                    ROUND(v.quantidade * v.valor_unitario,2) AS Bruto,
                    ROUND((v.quantidade * v.valor_unitario) * ((v.aliquota_icms + v.aliquota_pis + v.aliquota_cofins)/100),2) AS Impostos,
                    ROUND((v.quantidade * v.valor_unitario ) - ((v.quantidade * v.valor_unitario) * ((v.aliquota_icms + v.aliquota_pis + v.aliquota_cofins)/100)),2) AS Liquido
            FROM vendas v
                    INNER JOIN produtos p
                        ON p.id_produto=v.id_produto
                    INNER JOIN fornecedor f
                        ON f.id_fornecedor=p.id_fornecedor
                    INNER JOIN categoria c
                        ON c.id_categoria=p.id_categoria
                    INNER JOIN usuarios u
                        ON u.id=v.id_usuario
                    INNER JOIN departamento d
                        ON d.id_departamento=u.id_departamento
            WHERE v.data_venda  BETWEEN %s AND %s
        """

        parametros=[data_inicio,data_fim]

        if produto:

            query+="""

            AND p.nome_produto

            LIKE %s

            """

            parametros.append(

            f"%{produto}%"

            )


        if fornecedor:

            query+="""

            AND f.id_fornecedor=%s

            """

            parametros.append(
            fornecedor
            )


        if categoria:

            query+="""

            AND c.id_categoria=%s

            """

            parametros.append(
            categoria
            )

        if vendedor:
            query+="""

            AND u.id=%s

            """

            parametros.append(
            vendedor)
  
        query_total=f"""

        SELECT COUNT(*)
        FROM ({query}) x

        """

        cursor.execute(query_total,parametros)

        total_registros=cursor.fetchone()[0]

        total_paginas=max(1,math.ceil(total_registros/registros_por_pagina))

  
        query+="""

            ORDER BY 
                v.data_venda DESC

        LIMIT %s
        OFFSET %s

        """

        parametros.extend([registros_por_pagina,offset])

        cursor.execute(query,parametros)

        dados=cursor.fetchall()

    inicio=max(1, pagina-3)

    fim=min( total_paginas,  pagina+3)

    cursor.close()
    con.close()

    return render_template("relatorio_vendas_operacional.html",
        dados=dados,
        fornecedores=fornecedores,
        categorias=categorias,
        vendedores=vendedores,
        pagina=pagina,
        total_paginas=total_paginas,
        inicio=inicio,
        fim=fim)


# ======================================================
# RELATÓRIO FECHAMENTO MENSAL
# ======================================================


@app.route(
"/relatorio_vendas_mensal",
methods=["GET"]
)
def relatorio_vendas_mensal():

    ano=request.args.get("ano")
    meses=request.args.getlist("mes")

    dados=[]

    con=conectar()
    cursor=con.cursor()


    # Anos disponíveis

    cursor.execute("""

    SELECT DISTINCT
    YEAR(data_venda) AS ano

    FROM vendas

    ORDER BY ano

    """)

    anos=[x[0] for x in cursor.fetchall()]


    if ano:

        nome_mes="""

        CASE MONTH(v.data_venda)

        WHEN 1 THEN 'Janeiro'
        WHEN 2 THEN 'Fevereiro'
        WHEN 3 THEN 'Março'
        WHEN 4 THEN 'Abril'
        WHEN 5 THEN 'Maio'
        WHEN 6 THEN 'Junho'
        WHEN 7 THEN 'Julho'
        WHEN 8 THEN 'Agosto'
        WHEN 9 THEN 'Setembro'
        WHEN 10 THEN 'Outubro'
        WHEN 11 THEN 'Novembro'
        WHEN 12 THEN 'Dezembro'

        END

        """


        query=f"""

        SELECT

        YEAR(v.data_venda) AS Ano,

        {nome_mes} AS Mes,

        p.nome_produto,

        f.nome_fornecedor,

        c.nome_categoria,


        SUM(v.quantidade) AS Quantidade,


        ROUND(

            SUM(

                v.quantidade*
                v.valor_unitario

            )

        ,2)

        AS Bruto,


        ROUND(

            SUM(

                (

                v.quantidade*
                v.valor_unitario

                )

                *

                (

                    (

                    v.aliquota_icms+
                    v.aliquota_pis+
                    v.aliquota_cofins

                    )/100

                )

            )

        ,2)

        AS Impostos,


        ROUND(

            SUM(

                (

                v.quantidade*
                v.valor_unitario

                )

                -

                (

                    (

                    v.quantidade*
                    v.valor_unitario

                    )

                    *

                    (

                        (

                        v.aliquota_icms+
                        v.aliquota_pis+
                        v.aliquota_cofins

                        )/100

                    )

                )

            )

        ,2)

        AS Liquido


        FROM vendas v

        INNER JOIN produtos p
        ON p.id_produto=v.id_produto

        INNER JOIN fornecedor f
        ON f.id_fornecedor=p.id_fornecedor

        INNER JOIN categoria c
        ON c.id_categoria=p.id_categoria


        WHERE YEAR(v.data_venda)=%s

        """


        parametros=[ano]


        if meses:

            placeholders=','.join(
            ['%s']*len(meses)
            )

            query += f"""

            AND MONTH(v.data_venda)

            IN ({placeholders})

            """

            parametros.extend(
            meses
            )


        query += f"""

        GROUP BY

        YEAR(v.data_venda),

        MONTH(v.data_venda),

        {nome_mes},

        p.nome_produto,

        f.nome_fornecedor,

        c.nome_categoria


        ORDER BY

        YEAR(v.data_venda),

        MONTH(v.data_venda)

        """


        cursor.execute(
            query,
            parametros
        )

        dados=cursor.fetchall()


    cursor.close()
    con.close()


    return render_template(

    "relatorio_vendas_mensal.html",

    anos=anos,
    dados=dados

    )


# ======================================================
# EXPORTAÇÃO EXCEL OPERACIONAL
# ======================================================

@app.route("/exportar_operacional")
def exportar_operacional():

    nome=request.args.get("nome", "vendas_operacional")

    data_inicio=request.args.get( "data_inicio")

    data_fim=request.args.get( "data_fim" )

    con=conectar()

    query="""

    SELECT

        v.data_venda AS Data,
        p.nome_produto AS Produto,
        f.nome_fornecedor AS Fornecedor,
        c.nome_categoria AS Categoria,
        v.quantidade AS Quantidade,
        ROUND(v.quantidade * v.valor_unitario ,2) AS Valor_Bruto,
        ROUND(( v.quantidade * v.valor_unitario ) * ((v.aliquota_icms + v.aliquota_pis + v.aliquota_cofins)/100),2)AS Impostos,
        ROUND((v.quantidade * v.valor_unitario) - ((v.quantidade * v.valor_unitario) * ((v.aliquota_icms + v.aliquota_pis + v.aliquota_cofins)/100)),2) AS Valor_Liquido
    FROM vendas v
        INNER JOIN produtos p
            ON p.id_produto=v.id_produto
        INNER JOIN fornecedor f
            ON f.id_fornecedor=p.id_fornecedor
        INNER JOIN categoria c
            ON c.id_categoria=p.id_categoria
        WHERE
        v.data_venda BETWEEN %s AND %s
    ORDER BY
        v.data_venda DESC

    """

    df=pd.read_sql(
        query,
        con,
        params=[
            data_inicio,
            data_fim
        ]
    )

    arquivo=BytesIO()

    with pd.ExcelWriter(
        arquivo,
        engine='openpyxl'
    ) as writer:

        df.to_excel(
            writer,
            index=False
        )

    arquivo.seek(0)

    con.close()

    return send_file(

        arquivo,

        download_name=f"{nome}.xlsx",

        as_attachment=True

    )


# ======================================================
# EXPORTAÇÃO EXCEL MENSAL
# ======================================================

@app.route("/exportar_mensal")
def exportar_mensal():

    ano=request.args.get("ano")

    meses=request.args.getlist("mes")


    con=conectar()


    nome_mes="""

    CASE MONTH(v.data_venda)

    WHEN 1 THEN 'Janeiro'
    WHEN 2 THEN 'Fevereiro'
    WHEN 3 THEN 'Março'
    WHEN 4 THEN 'Abril'
    WHEN 5 THEN 'Maio'
    WHEN 6 THEN 'Junho'
    WHEN 7 THEN 'Julho'
    WHEN 8 THEN 'Agosto'
    WHEN 9 THEN 'Setembro'
    WHEN 10 THEN 'Outubro'
    WHEN 11 THEN 'Novembro'
    WHEN 12 THEN 'Dezembro'

    END

    """


    query=f"""

    SELECT

    YEAR(v.data_venda) AS Ano,

    {nome_mes} AS Mes,

    p.nome_produto AS Produto,

    f.nome_fornecedor AS Fornecedor,

    c.nome_categoria AS Categoria,

    SUM(v.quantidade) AS Quantidade,

    ROUND(
    SUM(
    v.quantidade*v.valor_unitario
    )
    ,2)

    AS Bruto,


    ROUND(

    SUM(

    (

    v.quantidade*
    v.valor_unitario

    )

    *

    (

    (

    v.aliquota_icms+
    v.aliquota_pis+
    v.aliquota_cofins

    )/100

    )

    )

    ,2)

    AS Impostos,


    ROUND(

    SUM(

    (

    v.quantidade*
    v.valor_unitario

    )

    -

    (

    (

    v.quantidade*
    v.valor_unitario

    )

    *

    (

    (

    v.aliquota_icms+
    v.aliquota_pis+
    v.aliquota_cofins

    )/100

    )

    )

    )

    ,2)

    AS Liquido


    FROM vendas v


    INNER JOIN produtos p
    ON p.id_produto=v.id_produto


    INNER JOIN fornecedor f
    ON f.id_fornecedor=p.id_fornecedor


    INNER JOIN categoria c
    ON c.id_categoria=p.id_categoria


    WHERE YEAR(v.data_venda)=%s

    """


    parametros=[ano]


    if meses:

        placeholders=','.join(

        ['%s']*len(meses)

        )

        query+=f"""

        AND MONTH(v.data_venda)

        IN ({placeholders})

        """

        parametros.extend(
        meses
        )


    query+=f"""

    GROUP BY

    YEAR(v.data_venda),

    MONTH(v.data_venda),

    {nome_mes},

    p.nome_produto,

    f.nome_fornecedor,

    c.nome_categoria


    ORDER BY

    YEAR(v.data_venda),

    MONTH(v.data_venda)

    """


    df=pd.read_sql(

    query,

    con,

    params=parametros

    )


    arquivo=BytesIO()


    with pd.ExcelWriter(

    arquivo,

    engine='openpyxl'

    ) as writer:

        df.to_excel(

        writer,

        index=False,

        sheet_name='Fechamento'

        )


    arquivo.seek(0)

    con.close()


    return send_file(

    arquivo,

    download_name=f"fechamento_{ano}.xlsx",

    as_attachment=True

    )



@app.route("/buscar_meses/<ano>")
def buscar_meses(ano):

    con=conectar()

    cursor=con.cursor()

    cursor.execute("""

    SELECT DISTINCT

    MONTH(data_venda)

    FROM vendas

    WHERE YEAR(data_venda)=%s

    ORDER BY
    MONTH(data_venda)

    """,

    (ano,)
    )

    meses=cursor.fetchall()

    cursor.close()
    con.close()

    return {

    "meses":[x[0] for x in meses]

    }


########################
## Analitico
########################


@app.route("/analytics")
def analytics():

    con=conectar()
    cursor=con.cursor()


    ############################################
    # FILTROS
    ############################################

    ano=request.args.get(
        "ano",
        type=int
    )

    mes=request.args.get(
        "mes",
        type=int
    )


    where=[]
    parametros=[]


    if ano:

        where.append(
            "t.ano=%s"
        )

        parametros.append(
            ano
        )


    if mes:

        where.append(
            "t.mes=%s"
        )

        parametros.append(
            mes
        )


    where_sql=""

    if where:

        where_sql="WHERE " + " AND ".join(where)



    ############################################
    # KPI
    ############################################

    query=f"""

    SELECT

        SUM(
            f.faturamento_bruto
        ),

        SUM(
            f.faturamento_liquido
        ),

        SUM(
            f.quantidade
        )

    FROM fato_vendas f

    INNER JOIN dim_tempo t
        ON t.id_tempo=f.id_tempo

    {where_sql}

    """


    cursor.execute(
        query,
        parametros
    )

    dados=cursor.fetchone()


    bruto=dados[0] or 0
    liquido=dados[1] or 0
    quantidade=dados[2] or 0


    faturamento=round(
        bruto,
        2
    )


    ticket=round(

        liquido/

        quantidade

        if quantidade else 0

    ,2)



    margem=round(

        (

            liquido/

            bruto

        )*100

        if bruto else 0

    ,2)



    atual=round(
        liquido,
        2)



    ############################################
    # ACUMULADO
    ############################################


    acumulado=0


    if ano:


        mes_limite=mes if mes else 12


        cursor.execute("""

        SELECT

        SUM(
            f.faturamento_liquido
        )

        FROM fato_vendas f

        INNER JOIN dim_tempo t
        ON t.id_tempo=f.id_tempo

        WHERE

        t.ano=%s

        AND

        t.mes<=%s

        """,

        [

            ano,
            mes_limite

        ]

        )


        acumulado=round(

            cursor.fetchone()[0] or 0

        ,2)




    ############################################
    # EVOLUÇÃO MENSAL
    ############################################

    query=f"""

    SELECT

        t.mes_ano,

        SUM(
            f.faturamento_liquido
        )

    FROM fato_vendas f

    INNER JOIN dim_tempo t
        ON t.id_tempo=f.id_tempo

    {where_sql}

    GROUP BY

        t.mes_ano,
        t.ano_mes

    ORDER BY

        t.ano_mes

    """


    cursor.execute(
        query,
        parametros
    )


    dados=cursor.fetchall()


    labels=[x[0] for x in dados]

    valores=[float(x[1]) for x in dados]



    ############################################
    # TOP 5 VENDEDORES
    ############################################

    query=f"""

    SELECT

        v.vendedor,

        SUM(
            f.faturamento_liquido
        )

    FROM fato_vendas f

    INNER JOIN dim_vendedor v
        ON v.id_vendedor_dim=f.id_vendedor_dim

    INNER JOIN dim_tempo t
        ON t.id_tempo=f.id_tempo

    {where_sql}

    GROUP BY

        v.vendedor

    ORDER BY

        SUM(
            f.faturamento_liquido
        ) DESC

    LIMIT 5

    """


    cursor.execute(
        query,
        parametros
    )

    dados=cursor.fetchall()


    top_vendedores=[x[0] for x in dados]

    top_valores=[float(x[1]) for x in dados]



    ############################################
    # TOP PRODUTOS
    ############################################

    query=f"""

    SELECT

        p.produto,

        SUM(
            f.faturamento_liquido
        )

    FROM fato_vendas f

    INNER JOIN dim_produto p
        ON p.id_produto_dim=f.id_produto_dim

    INNER JOIN dim_tempo t
        ON t.id_tempo=f.id_tempo

    {where_sql}

    GROUP BY

        p.produto

    ORDER BY

        SUM(
            f.faturamento_liquido
        ) DESC

    LIMIT 5

    """


    cursor.execute(
        query,
        parametros
    )


    dados=cursor.fetchall()


    produtos_top=[x[0] for x in dados]

    produtos_top_valor=[float(x[1]) for x in dados]




    ############################################
    # MENOS RENTÁVEIS
    ############################################


    query=f"""

    SELECT

        p.produto,

        SUM(
            f.faturamento_liquido
        )

    FROM fato_vendas f

    INNER JOIN dim_produto p
        ON p.id_produto_dim=f.id_produto_dim

    INNER JOIN dim_tempo t
        ON t.id_tempo=f.id_tempo

    {where_sql}

    GROUP BY

        p.produto

    ORDER BY

        SUM(
            f.faturamento_liquido
        )

    LIMIT 5

    """


    cursor.execute(
        query,
        parametros
    )


    dados=cursor.fetchall()


    produtos_bottom=[x[0] for x in dados]

    produtos_bottom_valor=[float(x[1]) for x in dados]



    ############################################
    # ANOS
    ############################################

    cursor.execute("""

    SELECT DISTINCT

    ano

    FROM dim_tempo

    ORDER BY ano

    """)

    anos=cursor.fetchall()

    con.close()



    return render_template(

        "analytics.html",

        faturamento=faturamento,
        ticket=ticket,
        margem=margem,
        atual=atual,
        acumulado=acumulado,

        anos=anos,

        labels=json.dumps(labels),
        valores=json.dumps(valores),

        top_vendedores=json.dumps(
            top_vendedores
        ),

        top_valores=json.dumps(
            top_valores
        ),

        produtos_top=json.dumps(
            produtos_top
        ),

        produtos_top_valor=json.dumps(
            produtos_top_valor
        ),

        produtos_bottom=json.dumps(
            produtos_bottom
        ),

        produtos_bottom_valor=json.dumps(
            produtos_bottom_valor
        ),

        selected_ano=ano,
        selected_mes=mes

    )

@app.route("/logout")
def logout():
    session.clear()
    return redirect("/")

app.run(debug=True)