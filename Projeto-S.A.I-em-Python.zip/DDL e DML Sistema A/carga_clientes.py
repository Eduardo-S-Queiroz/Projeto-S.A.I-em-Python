import pandas as pd
import mysql.connector

#  CONEXÃO
conexao = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="sistema_a"
)

cursor = conexao.cursor()

#  LER CSV (SEPARADOR ;)
df = pd.read_csv("Personagens Hitoricas Vfinal.csv", sep=";",encoding="utf-8-sig")

#  PADRONIZAR NOMES DAS COLUNAS
df.columns = df.columns.str.strip().str.lower()

print("Colunas encontradas:", df.columns)


#  TRATAMENTO DE DADOS
df["data_nasc"] = pd.to_datetime(
    df["data_nasc"],
    errors="coerce",
    dayfirst=True
)

df["data_nasc"] = df["data_nasc"].apply(
    lambda x: x.strftime("%Y-%m-%d") if pd.notnull(x) else None
)

df = df.where(pd.notnull(df), None)

#  INSERÇÃO
for index, row in df.iterrows():
    cursor.execute("""
       INSERT INTO clientes (
           nome,
           data_nasc,
           contexto_historico,
           cidade,
            uf,
            email,
            telefone,
            estado_civil,
            endereco,
            cpf
        ) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
    """, (
        row["nome"],
        row["data_nasc"],
        row["contexto_historico"],
        row["cidade"],
        row["uf"],
        row["email"],
        row["telefone_simulado"],
        row["estado_civil"],
        row["endereco_simulado"],
        row["cpf"]
    ))

conexao.commit()

print("Dados importados com sucesso!")

cursor.close()
conexao.close()