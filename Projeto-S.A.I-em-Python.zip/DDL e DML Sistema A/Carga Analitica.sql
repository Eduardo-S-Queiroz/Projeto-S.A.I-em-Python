 
## Analitico
use sistema_a

## DDL 

## DIM TEMPO

CREATE TABLE dim_tempo (
    id_tempo INT AUTO_INCREMENT PRIMARY KEY,
    data_completa DATE,
    dia INT,
    dia_semana_abrev VARCHAR(3),
    semana INT,
    quinzena INT,
    mes INT,
    nome_mes VARCHAR(20),
    trimestre INT,
    semestre INT,
    ano INT,
    mes_ano VARCHAR(10),
    ano_mes INT,
    dia_util CHAR(1),
    fim_semana CHAR(1),
    feriado CHAR(1),
    UNIQUE(data_completa),
    dt_carga DATETIME DEFAULT CURRENT_TIMESTAMP

);


# DIM PRODUTO

CREATE TABLE dim_produto (
    id_produto_dim INT AUTO_INCREMENT PRIMARY KEY,
    id_produto_origem INT,
    produto VARCHAR(200),
    categoria VARCHAR(100),
    fornecedor VARCHAR(100),
    dt_carga DATETIME DEFAULT CURRENT_TIMESTAMP
);

## DIM VENDEDOR
CREATE TABLE dim_vendedor (
    id_vendedor_dim INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario_origem INT,
    vendedor VARCHAR(150),
    departamento VARCHAR(100),    
    dt_carga DATETIME DEFAULT CURRENT_TIMESTAMP

);

## FATO VENDAS

/* Em DW/NM para fatos  a regra costuma ser:

Fato → medidas aditivas ou semiaditivas
Camada analítica → cálculos derivados


Porque:
Campos percentuais como:

margem_percentual
crescimento_percentual
participacao_percentual

não devem ficar materializados na fato quando dependem do contexto dos filtros.

Exemplo do problema:

Sem filtro:

Produto A
Bruto: 100.000
Líquido: 60.000

Margem=60%

Agora o usuário filtra:

Vendedor=João
Mês=Mai/2026
Categoria=Notebook

Resultado:

Bruto: 20.000
Líquido: 15.000

Margem=75%

Se a margem estivesse gravada na fato:

margem_percentual=60%

o dashboard mostraria algo incorreto.

*/

CREATE TABLE fato_vendas (

    id_tempo INT NOT NULL,
    id_produto_dim INT NOT NULL,
    id_vendedor_dim INT NOT NULL,
    quantidade INT,
    faturamento_bruto DECIMAL(18,2),
    impostos DECIMAL(18,2),
    faturamento_liquido DECIMAL(18,2),
    dt_carga DATETIME DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_tempo(id_tempo),

    INDEX idx_produto(id_produto_dim),

    INDEX idx_vendedor(id_vendedor_dim),

    CONSTRAINT fk_tempo
    FOREIGN KEY(id_tempo)
    REFERENCES dim_tempo(id_tempo),

    CONSTRAINT fk_produto
    FOREIGN KEY(id_produto_dim)
    REFERENCES dim_produto(id_produto_dim),

    CONSTRAINT fk_vendedor
    FOREIGN KEY(id_vendedor_dim)
    REFERENCES dim_vendedor(id_vendedor_dim)

);

## DML

## ETL - Das dimensões e da fato



## Carga DIM PRODUTO

INSERT INTO dim_produto(

	id_produto_origem,
	produto,
	categoria,
	fornecedor,
	dt_carga
)

SELECT

	p.id_produto,
	p.nome_produto,
	c.nome_categoria,
	f.nome_fornecedor,
	NOW()

FROM produtos p
	INNER JOIN categoria c
		ON c.id_categoria=p.id_categoria
	INNER JOIN fornecedor f
		ON f.id_fornecedor=p.id_fornecedor;

## Carga DIM Vendedor


INSERT INTO dim_vendedor(
	id_usuario_origem,
	vendedor,
	departamento,
	dt_carga)

select 	u.id,
		u.nome,
		d.nome_departamento,
		NOW()
FROM usuarios u
	INNER JOIN departamentos d
		ON d.id_departamento=u.id_departamento
WHERE d.nome_departamento='Vendas';

## Carga dim tempo (usado uma procedure)

DELIMITER $$

DROP PROCEDURE IF EXISTS popular_dim_tempo $$

CREATE PROCEDURE popular_dim_tempo()

BEGIN

    DECLARE data_inicio DATE;
    DECLARE data_fim DATE;

    SET data_inicio='2020-01-01';
    SET data_fim='2030-12-31';

    WHILE data_inicio <= data_fim DO

        INSERT IGNORE INTO dim_tempo(

            data_completa,
            dia,
            dia_semana_abrev,
            semana,
            quinzena,
            mes,
            nome_mes,
            trimestre,
            semestre,
            ano,
            mes_ano,
            ano_mes,
            dia_util,
            fim_semana,
            feriado,
            dt_carga

        )

        VALUES(

            data_inicio,

            DAY(data_inicio),

            CASE DAYOFWEEK(data_inicio)
                WHEN 1 THEN 'DOM'
                WHEN 2 THEN 'SEG'
                WHEN 3 THEN 'TER'
                WHEN 4 THEN 'QUA'
                WHEN 5 THEN 'QUI'
                WHEN 6 THEN 'SEX'
                WHEN 7 THEN 'SAB'
            END,

            WEEK(data_inicio),

            CASE
                WHEN DAY(data_inicio)<=15
                THEN 1
                ELSE 2
            END,

            MONTH(data_inicio),

            CASE MONTH(data_inicio)
                WHEN 1 THEN 'Janeiro'
                WHEN 2 THEN 'Fevereiro'
                WHEN 3 THEN 'Março'
                WHEN 4 THEN 'Abril'
                WHEN 5 THEN 'Maio'
                WHEN 6 THEN 'Junho'
                WHEN 7 THEN 'Julho'
                WHEN 8 THEN 'Agosto'
                WHEN 9 THEN 'Setembro'
                WHEN 10 THEN 'Outubro'
                WHEN 11 THEN 'Novembro'
                WHEN 12 THEN 'Dezembro'
            END,

            QUARTER(data_inicio),

            CASE
                WHEN MONTH(data_inicio)<=6
                THEN 1
                ELSE 2
            END,

            YEAR(data_inicio),

            CONCAT(

                CASE MONTH(data_inicio)

                    WHEN 1 THEN 'JAN'
                    WHEN 2 THEN 'FEV'
                    WHEN 3 THEN 'MAR'
                    WHEN 4 THEN 'ABR'
                    WHEN 5 THEN 'MAI'
                    WHEN 6 THEN 'JUN'
                    WHEN 7 THEN 'JUL'
                    WHEN 8 THEN 'AGO'
                    WHEN 9 THEN 'SET'
                    WHEN 10 THEN 'OUT'
                    WHEN 11 THEN 'NOV'
                    WHEN 12 THEN 'DEZ'

                END,

                ' ',

                RIGHT(YEAR(data_inicio),2)

            ),

            DATE_FORMAT(
                data_inicio,
                '%Y%m'
            ),

            CASE
                WHEN DAYOFWEEK(data_inicio) IN (1,7)
                THEN 'N'
                ELSE 'S'
            END,

            CASE
                WHEN DAYOFWEEK(data_inicio) IN (1,7)
                THEN 'S'
                ELSE 'N'
            END,

            'N',

            NOW()

        );

        SET data_inicio=
        DATE_ADD(
            data_inicio,
            INTERVAL 1 DAY
        );

    END WHILE;

END$$

DELIMITER ;

## Execução da Stored Procedure

CALL popular_dim_tempo();

## Validação da carga da dim_tempo

select 	data_completa,
		dia_semana_abrev,
		mes_ano,
		dia_util,
		fim_semana
FROM dim_tempo

WHERE dia=1
LIMIT 50;


## CArga da Tabela Fato

INSERT INTO fato_vendas(

	id_tempo,
	id_produto_dim,
	id_vendedor_dim,
	quantidade,
	faturamento_bruto,
	impostos,
	faturamento_liquido,
	dt_carga

	)

select 	dt.id_tempo AS id_tempo,
		dp.id_produto_dim AS id_produto_dim,
		dv.id_vendedor_dim AS id_vendedor_dim,
		SUM(v.quantidade) AS quantidade,
		ROUND(SUM(v.quantidade*v.valor_unitario),2)  AS faturamento_bruto,
		ROUND(SUM((v.quantidade*v.valor_unitario) * ((v.aliquota_icms+v.aliquota_pis+v.aliquota_cofins)/100)),2) AS impostos,
		ROUND(SUM((v.quantidade*v.valor_unitario) - ((v.quantidade*v.valor_unitario) * ((v.aliquota_icms+v.aliquota_pis+ v.aliquota_cofins)/100))),2) AS faturamento_liquido,
		NOW() AS dt_carga
FROM vendas v
	INNER JOIN dim_tempo dt
		ON dt.data_completa=v.data_venda
	INNER JOIN dim_produto dp
		ON dp.id_produto_origem=v.id_produto
	INNER JOIN dim_vendedor dv
		ON dv.id_usuario_origem=v.id_usuario
GROUP BY
	dt.id_tempo,
	dp.id_produto_dim,
	dv.id_vendedor_dim
	
	
select * from fato_vendas