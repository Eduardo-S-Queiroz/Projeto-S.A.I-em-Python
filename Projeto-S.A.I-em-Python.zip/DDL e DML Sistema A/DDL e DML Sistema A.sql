CREATE DATABASE IF NOT EXISTS sistema_a;
USE sistema_a;


-- USUÁRIOS
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(50),
    senha VARCHAR(50)
);

-- TIPOS DE DOCUMENTO
CREATE TABLE tipo_documento (
    id INT AUTO_INCREMENT PRIMARY KEY,
    descricao VARCHAR(50)
);

INSERT INTO tipo_documento (descricao) VALUES
('CPF'),
('RG'),
('CNH'),
('Passaporte');

-- PESSOAS
CREATE TABLE pessoas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tipo_documento_id INT,
    numero_documento VARCHAR(30),
    nome VARCHAR(50),
    sobrenome VARCHAR(50),
    nome_social VARCHAR(50),
    rua VARCHAR(100),
    cep VARCHAR(20),
    bairro VARCHAR(50),
    cidade VARCHAR(50),
    estado VARCHAR(50),
    telefone VARCHAR(20),
    filiacao VARCHAR(100),
    data_inclusao DATETIME DEFAULT CURRENT_TIMESTAMP,
    data_alteracao DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    FOREIGN KEY (tipo_documento_id) REFERENCES tipo_documento(id)
);

-- USUÁRIO INICIAL
INSERT INTO usuarios (nome, senha) VALUES
('admin', '1234');




CREATE TABLE sistema_a.clientes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(150),
    data_nasc DATE,
    contexto_historico TEXT,
    cidade VARCHAR(100),
    uf VARCHAR(2),
    email VARCHAR(150),
    telefone VARCHAR(20),
    estado_civil VARCHAR(50),
    endereco TEXT,
    cpf VARCHAR(20)
);





