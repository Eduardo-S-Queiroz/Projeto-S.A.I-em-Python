import mysql.connector
import random

from datetime import datetime,timedelta


# ==========================================
# CONEXÃO
# ==========================================

con=mysql.connector.connect(

    host="localhost",
    user="root",
    password="",
    database="sistema_a"

)

cursor=con.cursor()


# ==========================================
# CONFIGURAÇÕES
# ==========================================

DATA_INICIO=datetime(2024,1,1)

DATA_FIM=datetime(2026,5,18)


FATURAMENTO_MIN=5000000
FATURAMENTO_MAX=15000000


# ==========================================
# ALÍQUOTAS
# ==========================================

ICMS=18.00
PIS=1.65
COFINS=7.60


# ==========================================
# BUSCAR CLIENTES
# ==========================================

cursor.execute("""

SELECT id
FROM clientes

""")

clientes=[x[0] for x in cursor.fetchall()]


# ==========================================
# BUSCAR PRODUTOS + PREÇO
# ==========================================

cursor.execute("""

SELECT

id_produto,
preco

FROM produtos

""")

produtos=cursor.fetchall()


# ==========================================
# BUSCAR VENDEDORES
# Departamento vendas = 4 a 9
# (mais correto: buscar pelo nome)
# ==========================================

cursor.execute("""

SELECT

id as id_usuario

FROM usuarios

WHERE id_departamento=

(

SELECT id_departamento

FROM departamento

WHERE nome_departamento='Vendas'

)

""")

vendedores=[x[0] for x in cursor.fetchall()]


# ==========================================
# SAZONALIDADE
# ==========================================

def fator_trimestre(data):

    trimestre=(data.month-1)//3+1

    fatores={

        1:0.90,
        2:1.05,
        3:1.20,
        4:0.95

    }

    return fatores[trimestre]


# ==========================================
# GERAÇÃO
# ==========================================

data_atual=DATA_INICIO


while data_atual<=DATA_FIM:


    meta_mes=random.randint(

        FATURAMENTO_MIN,
        FATURAMENTO_MAX

    )

    faturado=0


    while faturado<meta_mes:


        id_cliente=random.choice(
            clientes
        )


        produto=random.choice(
            produtos
        )

        id_produto=produto[0]

        preco_base=float(
            produto[1]
        )


        id_usuario=random.choice(
            vendedores
        )


        fator=fator_trimestre(
            data_atual
        )


        valor_unitario=round(

            preco_base*fator,

            2

        )


        quantidade=random.randint(

            1,
            15

        )


        valor_bruto=(

            quantidade*
            valor_unitario

        )


        data_venda=(

            data_atual+

            timedelta(

                days=random.randint(
                    0,
                    27
                )

            )

        )


        cursor.execute("""

        INSERT INTO vendas(

            id_cliente,
            id_produto,
            id_usuario,
            data_venda,
            quantidade,
            valor_unitario,
            aliquota_icms,
            aliquota_pis,
            aliquota_cofins

        )

        VALUES(

            %s,
            %s,
            %s,
            %s,
            %s,
            %s,
            %s,
            %s,
            %s

        )

        """,

        (

            id_cliente,
            id_produto,
            id_usuario,
            data_venda,
            quantidade,
            valor_unitario,
            ICMS,
            PIS,
            COFINS

        )

        )


        faturado += valor_bruto


    # próximo mês

    if data_atual.month==12:

        data_atual=datetime(

            data_atual.year+1,
            1,
            1

        )

    else:

        data_atual=datetime(

            data_atual.year,
            data_atual.month+1,
            1

        )


con.commit()

cursor.close()
con.close()

print("Vendas geradas com sucesso.")

